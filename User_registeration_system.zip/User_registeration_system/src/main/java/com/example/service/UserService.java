package com.example.service;

import java.util.ArrayList;
import java.util.List;

public class UserService {
    private static List<User> users = new ArrayList<>();

    // Register a new user
    public static boolean registerUser(String username, String password, String email) {
        if (getUserByUsername(username) == null) {
            users.add(new User(username, password, email));
            return true;
        }
        return false; // Username already exists
    }

    // Validate login credentials
    public static boolean validateLogin(String username, String password) {
        User user = getUserByUsername(username);
        return user != null && user.getPassword().equals(password);
    }

    // Helper method to check if the username exists
    private static User getUserByUsername(String username) {
        for (User user : users) {
            if (user.getUsername().equalsIgnoreCase(username)) {
                return user;
            }
        }
        return null;
    }
}

